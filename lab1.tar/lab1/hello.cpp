#include <iostream>
using namespace std;

int main()
{
	cout << "Hello world from linux!" << endl;
	return 0;
}
